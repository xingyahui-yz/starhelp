"""Pure verification of signed metadata and artifact-specific public basis."""

from __future__ import annotations

import hashlib
from datetime import timedelta

from ..common import canonical, digest, fail
from .policy import c_tuple, signing_key, snapshot_tuple
from .schema import (CAPABILITIES, CATALOG, NATIVE, PROFILE, REF_KEYS,
                     RELEASE_KEYS, REVOCATIONS, hex_value, integer, obj,
                     release_ref, text, typed_ref, utc)

BASE_FIELDS = set("schema_version origin_id channel consumer_profile sequence issued_at valid_until".split())
BASIS_FIELDS = set("profile origin_id channel consumer_profile policy_id policy_revision policy_sha256 epoch selected_artifact qualification_pair latest_pair qualified_at offline_until evaluation_time state".split())
SELECTED_FIELDS = {"release_id", "envelope_sha256", "a_producer", "planner", "b_snapshot"}
DESCRIPTOR_FIELDS = SELECTED_FIELDS | {"download_path", "size_bytes", "envelope_profile", "required_capabilities", "rollback_allowed"}
REASONS = {"rights_withdrawn", "source_correction", "integrity_issue", "policy_change"}
_UNRESERVED = frozenset(b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")


def verify_signature(message, signature, key):
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError:
        fail("signature_verification_unavailable", "optional producer-signature dependency is required")
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(key["public_key_hex"])).verify(
            bytes.fromhex(signature), message)
    except Exception:
        fail("invalid_signature", "signed metadata verification failed")


def relative_path(value):
    text(value)
    if (not value.startswith("/") or value.startswith("//") or "://" in value
            or any(c in value for c in ("?", "#", "\\", "%"))
            or any(p in {".", ".."} for p in value.split("/"))):
        fail("invalid_public_document", "fixed same-origin relative path required")


def revocation_snapshot_path(value, context):
    text(value)
    channel = text(context["channel"])
    encoded_channel = "".join(
        chr(byte) if byte in _UNRESERVED else f"%{byte:02X}"
        for byte in channel.encode("utf-8")
    )
    expected = (f"/v1/distribution-revocations?profile={context['consumer_profile']}"
                f"&channel={encoded_channel}")
    if value != expected:
        fail("invalid_public_document", "revocation path must bind the fixed profile and channel route")


def selected_shape(selected):
    obj(selected, SELECTED_FIELDS)
    text(selected["release_id"])
    hex_value(selected["envelope_sha256"])
    obj(selected["a_producer"], {"package", "version", "commit"})
    for key in ("package", "version"):
        text(selected["a_producer"][key])
    hex_value(selected["a_producer"]["commit"], 40)
    c_tuple(selected["planner"])
    snapshot_tuple(selected["b_snapshot"])


def descriptor_shape(entry):
    obj(entry, DESCRIPTOR_FIELDS, code="invalid_public_document")
    selected_shape({key: entry[key] for key in SELECTED_FIELDS})
    relative_path(entry["download_path"])
    if entry["download_path"] != "/v1/distributions/" + entry["release_id"]:
        fail("invalid_public_document", "artifact path must bind its exact release identity")
    integer(entry["size_bytes"])
    if entry["envelope_profile"] != "starhelp.b-publicbundle-envelope.v1":
        fail("unsupported_public_schema", "unknown distribution envelope profile")
    capabilities = entry["required_capabilities"]
    if (type(capabilities) is not list or any(type(c) is not str for c in capabilities)
            or capabilities != sorted(set(capabilities))
            or type(entry["rollback_allowed"]) is not bool):
        fail("invalid_public_document", "invalid descriptor capabilities/rollback flag")


def signed_document(raw, expected_profile, config, context):
    obj(raw, {"profile", "payload", "signature"}, code="invalid_public_document")
    if raw["profile"] != expected_profile:
        fail("unsupported_public_document_profile", "metadata signature domain differs")
    signature = obj(raw["signature"], {"algorithm", "key_id", "value"}, code="invalid_public_document")
    if signature["algorithm"] != "Ed25519":
        fail("invalid_signature", "only Ed25519 metadata signatures are supported")
    text(signature["key_id"])
    hex_value(signature["value"], 128, "invalid_signature")
    purpose = "synthetic-" + ("catalog" if expected_profile == CATALOG else "revocations")
    key = signing_key(config, signature["key_id"], purpose, utc(context["evaluation_time"]))
    signed = {"profile": expected_profile, "algorithm": signature["algorithm"],
              "key_id": signature["key_id"], "payload": raw["payload"]}
    verify_signature(expected_profile.encode("ascii") + b"\n" + canonical(signed), signature["value"], key)
    extra = {"active_release_id", "distributions", "revocation_snapshot"} if expected_profile == CATALOG else {"revoked_releases", "revoked_public_refs"}
    payload = obj(raw["payload"], BASE_FIELDS | extra, code="invalid_public_document")
    if payload["schema_version"] != expected_profile:
        fail("unsupported_public_document_profile", "unknown signed payload schema")
    for name in ("origin_id", "channel", "consumer_profile"):
        if payload[name] != context[name]:
            fail("public_context_mismatch", "signed metadata belongs to another trust scope")
    integer(payload["sequence"])
    issued, until = utc(payload["issued_at"]), utc(payload["valid_until"])
    now = utc(context["evaluation_time"])
    freshness = config["freshness"]
    if not utc(key["not_before"]) <= issued < utc(key["not_after"]):
        fail("signing_key_expired", "metadata was issued outside its key's admitted lifetime")
    if (until <= issued or until - issued > timedelta(seconds=freshness["catalog_ttl_seconds"])
            or issued > now + timedelta(seconds=freshness["clock_skew_seconds"])):
        fail("public_document_time_invalid", "metadata issue/expiry interval is not admissible")
    if expected_profile == CATALOG:
        entries = payload["distributions"]
        if type(entries) is not list or not 1 <= len(entries) <= 2:
            fail("invalid_public_document", "catalog requires one active and at most one rollback entry")
        for entry in entries:
            descriptor_shape(entry)
        ids = [e["release_id"] for e in entries]
        if ids != sorted(set(ids)) or ids.count(payload["active_release_id"]) != 1:
            fail("invalid_public_document", "catalog release identities/active pointer are invalid")
        if any(e["rollback_allowed"] == (e["release_id"] == payload["active_release_id"]) for e in entries):
            fail("invalid_public_document", "only an explicit non-active rollback target can be allowed")
        ref = obj(payload["revocation_snapshot"], {"path", "sha256", "size_bytes", "sequence"})
        revocation_snapshot_path(ref["path"], context)
        hex_value(ref["sha256"])
        integer(ref["size_bytes"])
        integer(ref["sequence"])
    else:
        for name, identity_keys, validator in (("revoked_releases", RELEASE_KEYS, release_ref),
                                               ("revoked_public_refs", REF_KEYS, typed_ref)):
            values = payload[name]
            if type(values) is not list:
                fail("invalid_public_document", "complete revocation arrays are required")
            identities = []
            for value in values:
                obj(value, identity_keys | {"reason_code", "effective_at"})
                identity = {k: value[k] for k in identity_keys}
                validator(identity)
                if value["reason_code"] not in REASONS or utc(value["effective_at"]) > issued:
                    fail("invalid_public_document", "only already-effective, enumerated revocations are supported")
                identities.append(tuple(identity[k] for k in sorted(identity_keys)))
            if len(identities) != len(set(identities)):
                fail("invalid_public_document", "duplicate signed tombstone")
            if name == "revoked_releases" and len({v["release_id"] for v in values}) != len(values):
                fail("invalid_public_document", "one release ID cannot bind multiple raw digests")
    return payload


def verify_public_basis(request, policy, budget):
    config, context = policy["config"], policy["context"]
    basis = obj(request["public_basis"], BASIS_FIELDS, code="invalid_public_basis")
    if basis["profile"] != "starhelp.public-basis.v1":
        fail("invalid_public_basis", "unknown public basis profile")
    actual = digest(basis)
    if request["public_basis_sha256"] != actual:
        fail("public_basis_digest_mismatch", "public basis canonical digest differs")
    if (basis["epoch"] != context["public_epoch"] or actual != context["basis_sha256"]
            or basis["evaluation_time"] != context["evaluation_time"]):
        fail("public_basis_changed", "request is not bound to the current trusted public context")
    integer(basis["epoch"])
    integer(basis["policy_revision"])
    if (basis["policy_id"] != config["policy_id"] or basis["policy_revision"] != config["revision"]
            or basis["policy_sha256"] != digest(config)):
        fail("execution_policy_mismatch", "basis does not bind the separately configured policy")
    for name in ("origin_id", "channel", "consumer_profile"):
        if basis[name] != context[name]:
            fail("public_context_mismatch", "basis and trusted origin/channel/consumer differ")
    if context["safety_state"] != "ready" or basis["state"] not in {"fresh", "offline_stale"}:
        fail("public_basis_unusable", "host recovery, clock or revocation safety gate is closed")
    selected = basis["selected_artifact"]
    selected_shape(selected)
    if (selected["planner"] not in config["allowed_c_components"]
            or selected["planner"]["component_version"] != "0.5.1"
            or selected["planner"]["profile"] != NATIVE
            or selected["planner"]["producer_profile"] != PROFILE):
        fail("unsupported_component_tuple", "selected artifact requires another admitted C component")
    documents = request["public_documents"]
    if type(documents) is not dict or not 2 <= len(documents) <= config["limits"]["documents_count"]:
        fail("invalid_public_documents", "two to four deduplicated signed documents are required")
    parsed, sizes = {}, {}
    for raw_digest, wrapper in documents.items():
        hex_value(raw_digest)
        obj(wrapper, {"profile", "raw_json"}, code="invalid_public_documents")
        profile = wrapper["profile"]
        if profile not in {CATALOG, REVOCATIONS}:
            fail("unsupported_public_document_profile", "unknown metadata profile")
        limit = "catalog_raw_bytes" if profile == CATALOG else "revocations_raw_bytes"
        raw, encoded = budget.raw(wrapper["raw_json"], config["limits"][limit])
        if hashlib.sha256(encoded).hexdigest() != raw_digest:
            fail("public_document_digest_mismatch", "metadata raw bytes do not match the document key")
        parsed[raw_digest] = (profile, signed_document(raw, profile, config, context))
        sizes[raw_digest] = len(encoded)

    def pair(value):
        obj(value, {"catalog_sha256", "revocations_sha256"}, code="invalid_public_basis")
        for name, profile in (("catalog_sha256", CATALOG), ("revocations_sha256", REVOCATIONS)):
            hex_value(value[name])
            if value[name] not in parsed or parsed[value[name]][0] != profile:
                fail("public_document_missing", "basis does not reference its complete signed pair")
        catalog = parsed[value["catalog_sha256"]][1]
        revocations = parsed[value["revocations_sha256"]][1]
        ref = catalog["revocation_snapshot"]
        if (ref["sha256"] != value["revocations_sha256"] or ref["size_bytes"] != sizes[value["revocations_sha256"]]
                or ref["sequence"] != revocations["sequence"]):
            fail("public_pair_mismatch", "catalog does not bind these exact revocation bytes/sequence")
        return catalog, revocations

    qualification = pair(basis["qualification_pair"])
    latest = pair(basis["latest_pair"])
    used = set(basis["qualification_pair"].values()) | set(basis["latest_pair"].values())
    if used != set(documents):
        fail("invalid_public_documents", "unreferenced documents cannot alter the safety basis")
    for index, field in enumerate(("catalog_sha256", "revocations_sha256")):
        if latest[index]["sequence"] < qualification[index]["sequence"]:
            fail("public_sequence_replay", "latest metadata cannot precede qualification metadata")
        if (latest[index]["sequence"] == qualification[index]["sequence"]
                and basis["latest_pair"][field] != basis["qualification_pair"][field]):
            fail("public_sequence_conflict", "one sequence must retain the same original bytes")
    matches = [entry for entry in qualification[0]["distributions"] if entry["release_id"] == selected["release_id"]]
    if len(matches) != 1 or any(matches[0][k] != selected[k] for k in SELECTED_FIELDS):
        fail("artifact_not_qualified", "the qualification pair did not admit this exact artifact/tuple")
    descriptor = matches[0]
    if not set(descriptor["required_capabilities"]) <= CAPABILITIES:
        fail("unsupported_producer_capability", "selected artifact needs an unsupported capability")
    for entry in latest[0]["distributions"]:
        if entry["release_id"] == selected["release_id"] and entry["envelope_sha256"] != selected["envelope_sha256"]:
            fail("public_sequence_conflict", "an immutable release changed raw digest")
    now = utc(context["evaluation_time"])
    qualified = utc(basis["qualified_at"])
    until = utc(basis["offline_until"])
    skew = timedelta(seconds=config["freshness"]["clock_skew_seconds"])
    if (qualified > now + skew or until <= qualified
            or until > qualified + timedelta(seconds=config["freshness"]["offline_max_seconds"])):
        fail("artifact_qualification_time_invalid", "artifact offline deadline cannot be extended")
    for document in qualification:
        if not utc(document["issued_at"]) - skew <= qualified < utc(document["valid_until"]):
            fail("artifact_qualification_time_invalid", "artifact was not qualified inside its own signed pair window")
    if now >= until:
        fail("public_basis_expired", "artifact-specific offline window has expired")
    if basis["state"] == "fresh" and (
            basis["qualification_pair"] != basis["latest_pair"]
            or any(now >= utc(doc["valid_until"]) for doc in (*qualification, *latest))):
        fail("public_basis_state_mismatch", "old or expired qualification must be explicitly offline_stale")
    releases = list(context["known_revoked_releases"])
    refs = list(context["known_revoked_public_refs"])
    for _, revoke in (qualification, latest):
        releases.extend({k: row[k] for k in RELEASE_KEYS} for row in revoke["revoked_releases"])
        refs.extend({k: row[k] for k in REF_KEYS} for row in revoke["revoked_public_refs"])
    if any(all(row[k] == selected[k] for k in RELEASE_KEYS) for row in releases):
        fail("public_release_revoked", "selected artifact is present in cumulative known revocations")
    return descriptor, refs
