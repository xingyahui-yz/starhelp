"""Validate separately injected host policy; requests cannot create trust."""

from __future__ import annotations

from ..common import canonical, fail
from .schema import (A_KEYS, BUILDER_KEYS, C_KEYS, FRESHNESS, LIMITS, NATIVE,
                     SNAPSHOT_KEYS, copy_json, hex_value, integer, obj,
                     release_ref, text, typed_ref, utc)

CONFIG_KEYS = set("profile policy_id revision allow_production keys allowed_a_producers allowed_b_snapshots allowed_request_producers allowed_c_components limits freshness".split())
CONTEXT_KEYS = set("origin_id channel consumer_profile public_epoch basis_sha256 evaluation_time known_revoked_releases known_revoked_public_refs safety_state".split())
PURPOSES = {f"{environment}-{kind}" for environment in ("synthetic", "production")
            for kind in ("release", "catalog", "revocations")}


def exact_strings(value):
    if any(type(item) is str and any(char in item for char in "*?[]") for item in value.values()):
        fail("invalid_execution_policy", "wildcards are forbidden in producer/component admission tuples")


def rows(value, validate):
    if type(value) is not list:
        fail("invalid_execution_policy", "policy collections must be arrays")
    seen = set()
    for item in value:
        validate(item)
        encoded = canonical(item)
        if encoded in seen:
            fail("invalid_execution_policy", "duplicate policy/identity entry")
        seen.add(encoded)


def a_tuple(value):
    obj(value, A_KEYS, code="invalid_execution_policy")
    exact_strings(value)
    for key in A_KEYS - {"commit"}:
        text(value[key], "invalid_execution_policy")
    hex_value(value["commit"], 40, "invalid_execution_policy")
    if (value["package"] != "starhelp-knowledge"
            or value["envelope_profile"] != "starhelp.b-publicbundle-envelope.v1"
            or value["native_profile"] != "starhelp.knowledge.native.v0.1-draft"
            or value["planner_profile"] != NATIVE):
        fail("invalid_execution_policy", "unsupported A export semantics")


def snapshot_tuple(value):
    obj(value, SNAPSHOT_KEYS, code="invalid_execution_policy")
    exact_strings(value)
    text(value["profile"], "invalid_execution_policy")
    hex_value(value["producer_commit"], 40, "invalid_execution_policy")
    if value["profile"] != "starhelp.desktop.snapshot.interop-min.v0.1":
        fail("unsupported_snapshot_schema", "v0.2 only supports the unchanged ten/seven-key snapshot format")


def builder_tuple(value):
    obj(value, BUILDER_KEYS, code="unsupported_request_producer")
    exact_strings(value)
    if value["name"] != "starhelp-desktop" or value["artifact_kind"] != "source-lock":
        fail("unsupported_request_producer", "explicit desktop source-lock producer required")
    for key in ("package_version", "builder_module"):
        text(value[key], "unsupported_request_producer")
    for key in ("source_commit", "builder_blob"):
        hex_value(value[key], 40, "unsupported_request_producer")
    for key in ("dependency_lock_sha256", "artifact_sha256"):
        hex_value(value[key], code="unsupported_request_producer")


def c_tuple(value):
    obj(value, C_KEYS, code="invalid_execution_policy")
    exact_strings(value)
    for key in C_KEYS - {"wheel_sha256"}:
        text(value[key], "invalid_execution_policy")
    hex_value(value["wheel_sha256"], code="invalid_execution_policy")


def validate_execution_policy(execution_policy):
    """Return a detached validated policy, or raise structured AdaptationError.

    This validates an already trusted host argument, not its publisher or storage.
    C never opens a policy file. First-round production is unconditionally disabled.
    """
    policy = copy_json(execution_policy)
    obj(policy, {"config", "context"}, code="invalid_execution_policy")
    config = obj(policy["config"], CONFIG_KEYS, code="invalid_execution_policy")
    context = obj(policy["context"], CONTEXT_KEYS, code="invalid_execution_policy")
    if config["profile"] != "starhelp.execution-policy.v1":
        fail("invalid_execution_policy", "unknown trusted policy profile")
    text(config["policy_id"], "invalid_execution_policy")
    integer(config["revision"], "invalid_execution_policy")
    if config["allow_production"] is not False:
        fail("production_execution_disabled", "component 0.5.1 is restricted to synthetic execution policy")
    obj(config["limits"], set(LIMITS), code="invalid_execution_policy")
    for key, maximum in LIMITS.items():
        if integer(config["limits"][key], "invalid_execution_policy") > maximum:
            fail("invalid_execution_policy", "policy cannot enlarge the protocol budget")
    obj(config["freshness"], set(FRESHNESS), code="invalid_execution_policy")
    for key, maximum in FRESHNESS.items():
        if integer(config["freshness"][key], "invalid_execution_policy") > maximum:
            fail("invalid_execution_policy", "development freshness exceeds the bounded policy")
    for name, validator in (("allowed_a_producers", a_tuple),
                            ("allowed_b_snapshots", snapshot_tuple),
                            ("allowed_request_producers", builder_tuple),
                            ("allowed_c_components", c_tuple)):
        rows(config[name], validator)
    key_ids = set()
    for key in config["keys"] if type(config["keys"]) is list else [None]:
        obj(key, set("key_id public_key_hex purposes not_before not_after revoked".split()), code="invalid_execution_policy")
        text(key["key_id"], "invalid_execution_policy")
        if key["key_id"] in key_ids:
            fail("invalid_execution_policy", "duplicate signing key ID")
        key_ids.add(key["key_id"])
        hex_value(key["public_key_hex"], code="invalid_execution_policy")
        if (type(key["purposes"]) is not list or not key["purposes"]
                or any(type(p) is not str or p not in PURPOSES for p in key["purposes"])
                or len(key["purposes"]) != len(set(key["purposes"]))
                or type(key["revoked"]) is not bool):
            fail("invalid_execution_policy", "invalid purpose-bound key policy")
        if utc(key["not_after"]) <= utc(key["not_before"]):
            fail("invalid_execution_policy", "key validity interval is empty")
    for field in ("origin_id", "channel"):
        text(context[field], "invalid_execution_policy")
    if context["consumer_profile"] != NATIVE:
        fail("invalid_execution_policy", "unsupported trusted consumer profile")
    integer(context["public_epoch"], "invalid_execution_policy")
    hex_value(context["basis_sha256"], code="invalid_execution_policy")
    utc(context["evaluation_time"], "invalid_execution_policy")
    if type(context["safety_state"]) is not str or context["safety_state"] not in {"ready", "pending", "recovery_required", "clock_untrusted"}:
        fail("invalid_execution_policy", "unknown host safety state")
    rows(context["known_revoked_releases"], release_ref)
    rows(context["known_revoked_public_refs"], typed_ref)
    return policy


def signing_key(config, key_id, purpose, evaluation_time):
    matches = [key for key in config["keys"] if key["key_id"] == key_id]
    if not matches:
        fail("unknown_signing_key", "signing key is not admitted by trusted host policy")
    key = matches[0]
    if purpose not in key["purposes"] or not purpose.startswith("synthetic-"):
        fail("signing_key_purpose_mismatch", "signing key is not authorized for this object purpose")
    if key["revoked"]:
        fail("signing_key_revoked", "known revoked key cannot authorize execution")
    if not utc(key["not_before"]) <= evaluation_time < utc(key["not_after"]):
        fail("signing_key_expired", "signing key is outside its configured validity interval")
    return key
