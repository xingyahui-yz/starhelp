"""Closed, bounded JSON primitives for the pure v0.2 boundary."""

from __future__ import annotations

import json
import math
import re
from copy import deepcopy
from datetime import datetime
from typing import Any

from ..common import canonical, fail

PROFILE = "starhelp.producers.v0.2"
NATIVE = "starhelp.local.v0.2"
CATALOG = "starhelp.public-distribution-catalog.v1"
REVOCATIONS = "starhelp.public-revocations.v1"
HASH_PROFILE = "starhelp.a-native-content-field.v1"
KINDS = {"entity", "knowledge", "stage", "template", "variant", "troubleshooting", "resource", "evidence"}
CAPABILITIES = frozenset({PROFILE, "starhelp.public-basis.v1", "starhelp.request-producer.v1", "starhelp.local-profile.v0.2", "starhelp.knowledge-distribution.v1"})
LIMITS = {
    "request_bytes": 8 * 1024**2, "response_bytes": 16 * 1024**2,
    "envelope_raw_bytes": 2 * 1024**2, "snapshot_raw_bytes": 512 * 1024,
    "catalog_raw_bytes": 128 * 1024, "revocations_raw_bytes": 256 * 1024,
    "feedback_bytes": 64 * 1024, "feedback_fields": 64, "documents_count": 4,
    "json_nodes": 100_000, "json_depth": 48, "raw_chars": 8_000_000,
}
FRESHNESS = {"catalog_ttl_seconds": 86400, "refresh_interval_seconds": 21600,
             "offline_max_seconds": 259200, "clock_skew_seconds": 300}
BUILDER_KEYS = set("name package_version source_commit builder_module builder_blob dependency_lock_sha256 artifact_kind artifact_sha256".split())
A_KEYS = set("package version commit envelope_profile native_profile planner_profile".split())
C_KEYS = set("profile producer_profile component_version wheel_sha256".split())
SNAPSHOT_KEYS = {"profile", "producer_commit"}
REF_KEYS = {"kind", "id", "revision", "hash_profile", "content_hash"}
RELEASE_KEYS = {"release_id", "envelope_sha256"}
INNER_KEYS = set("schema_id schema_version adapter_profile request_id request_producer public_bundle account_snapshot authorization_context task evaluation_time public_basis public_basis_sha256 public_documents".split())


def obj(value: Any, required: set[str], optional: set[str] | None = None,
        code: str = "invalid_producer_payload") -> dict:
    if type(value) is not dict or not required <= value.keys() or set(value) - required - (optional or set()):
        fail(code, "closed object has missing or unsupported fields")
    return value


def text(value: Any, code: str = "invalid_producer_payload") -> str:
    if type(value) is not str or not value or value != value.strip() or any(ord(c) < 32 for c in value):
        fail(code, "a nonempty, unambiguous string is required")
    return value


def integer(value: Any, code: str = "invalid_producer_payload") -> int:
    if type(value) is not int or value < 1:
        fail(code, "positive integer required; booleans are not integers")
    return value


def hex_value(value: Any, size: int = 64, code: str = "invalid_producer_payload") -> str:
    if type(value) is not str or not re.fullmatch(r"[0-9a-f]{" + str(size) + "}", value):
        fail(code, "lowercase fixed-width hexadecimal value required")
    return value


def utc(value: Any, code: str = "invalid_producer_payload") -> datetime:
    if type(value) is not str or not re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?Z", value):
        fail(code, "explicit Z UTC timestamp required")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        fail(code, "invalid UTC timestamp")


class Budget:
    def __init__(self, limits: dict | None = None):
        self.limits = limits or LIMITS
        self.remaining = self.limits["json_nodes"]

    def check(self, value: Any) -> None:
        active: set[int] = set()

        def walk(item, depth):
            self.remaining -= 1
            if self.remaining < 0 or depth > self.limits["json_depth"]:
                fail("local_payload_too_large", "JSON node/depth budget exceeded")
            if item is None or type(item) in {str, int, bool}:
                return
            if type(item) is float and math.isfinite(item):
                return
            if type(item) not in {dict, list} or id(item) in active:
                fail("invalid_producer_payload", "finite acyclic built-in JSON required")
            active.add(id(item))
            if type(item) is dict and any(type(k) is not str for k in item):
                fail("invalid_producer_payload", "JSON object keys must be strings")
            for child in (item.values() if type(item) is dict else item):
                walk(child, depth + 1)
            active.remove(id(item))

        walk(value, 0)

    def raw(self, value: Any, byte_limit: int) -> tuple[dict, bytes]:
        if type(value) is not str or len(value) > self.limits["raw_chars"]:
            fail("local_payload_too_large", "raw JSON character budget exceeded")
        encoded = value.encode("utf-8")
        if len(encoded) > byte_limit:
            fail("local_payload_too_large", "raw JSON byte budget exceeded")

        def pairs(items):
            result = {}
            for key, child in items:
                if key in result:
                    fail("invalid_producer_payload", "duplicate raw JSON key")
                result[key] = child
            return result

        def constant(_):
            fail("invalid_producer_payload", "non-finite raw JSON number")

        parsed = json.loads(value, object_pairs_hook=pairs, parse_constant=constant)
        self.check(parsed)
        if type(parsed) is not dict:
            fail("invalid_producer_payload", "raw document root must be an object")
        return parsed, encoded


def copy_json(value: Any, limits: dict | None = None) -> Any:
    Budget(limits).check(value)
    return deepcopy(value)


def bounded_encoding(value: Any, maximum: int) -> bytes:
    encoded = canonical(value) + b"\n"
    if len(encoded) > maximum:
        fail("local_payload_too_large", "complete encoded JSON including LF exceeds budget")
    return encoded


def typed_ref(value: Any) -> dict:
    obj(value, REF_KEYS, code="invalid_revocation_identity")
    if type(value["kind"]) is not str or value["kind"] not in KINDS:
        fail("invalid_revocation_identity", "unknown native object kind")
    text(value["id"])
    integer(value["revision"])
    if value["hash_profile"] != HASH_PROFILE:
        fail("unsupported_revocation_hash_profile", "native content-field hash profile required")
    hex_value(value["content_hash"])
    return value


def release_ref(value: Any) -> dict:
    obj(value, RELEASE_KEYS, code="invalid_revocation_identity")
    text(value["release_id"])
    hex_value(value["envelope_sha256"])
    return value
