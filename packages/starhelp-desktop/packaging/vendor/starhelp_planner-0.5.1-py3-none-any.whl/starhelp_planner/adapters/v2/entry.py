"""Producer v0.2 entry point. Pure memory, separate host trust, no legacy fallback."""

from __future__ import annotations

import hashlib

from ...api import analyze
from ...validation import validate_json_request
from ..a_distribution import _adapt_distribution
from ..b_snapshot import _adapt_snapshot
from ..common import AdaptationError, COMPONENT_VERSION, canonical, digest, fail
from .documents import verify_public_basis
from .identity import map_revocations
from .policy import builder_tuple, signing_key, validate_execution_policy
from .schema import (INNER_KEYS, LIMITS, NATIVE, PROFILE, Budget, bounded_encoding,
                     copy_json, hex_value, integer, obj, text, utc)


def feedback_shape(feedback, task, limits):
    if feedback is None:
        return
    obj(feedback, {"fields"}, {"scope", "variant_id", "variant_revision"})
    if len(canonical(feedback)) > limits["feedback_bytes"]:
        fail("local_payload_too_large", "canonical local feedback exceeds byte budget")
    fields = feedback["fields"]
    if type(fields) is not dict or not 1 <= len(fields) <= limits["feedback_fields"]:
        fail("local_payload_too_large", "feedback requires a bounded nonempty field collection")
    if "scope" in feedback and feedback["scope"] != task["scope"]:
        fail("feedback_scope_mismatch", "feedback belongs to another task scope")
    if ("variant_id" in feedback) != ("variant_revision" in feedback):
        fail("invalid_feedback", "feedback variant must bind ID and revision")
    if "variant_id" in feedback:
        text(feedback["variant_id"])
        integer(feedback["variant_revision"])
    for name, fact in fields.items():
        text(name)
        if len(name) > 160:
            fail("invalid_feedback", "feedback field identity is too long")
        obj(fact, {"value", "state", "unit", "measurement_context"}, {"scope", "observed_at", "valid_until"})
        if fact["value"] is None or fact["state"] != "user_reported":
            fail("invalid_feedback", "feedback must remain explicitly user reported")
        text(fact["unit"])
        context = obj(fact["measurement_context"], {"phase", "assumptions"})
        text(context["phase"])
        if type(context["assumptions"]) is not list or len(context["assumptions"]) > 32:
            fail("invalid_feedback", "feedback assumptions must be bounded strings")
        for assumption in context["assumptions"]:
            text(assumption)
        for name in ("observed_at", "valid_until"):
            if name in fact:
                utc(fact[name])
        if "scope" in fact:
            obj(fact["scope"], set(), set(task["scope"]))
            if any(task["scope"].get(key) != value for key, value in fact["scope"].items()):
                fail("feedback_scope_mismatch", "feedback fact belongs to another scope")


def _prepare(request, policy):
    config, context = policy["config"], policy["context"]
    limits = config["limits"]
    clean = copy_json(request, limits)
    bounded_encoding(clean, limits["request_bytes"])
    obj(clean, INNER_KEYS, {"feedback"})
    if clean["schema_id"] != "ProducerAnalysisRequest" or clean["schema_version"] != "0.2" or clean["adapter_profile"] != PROFILE:
        fail("unsupported_adapter_profile", "explicit producer v0.2 schema/profile required")
    text(clean["request_id"])
    builder_tuple(clean["request_producer"])
    if clean["request_producer"] not in config["allowed_request_producers"]:
        fail("unsupported_request_producer", "builder source/artifact is absent from independent host admission policy")
    if clean["evaluation_time"] != context["evaluation_time"]:
        fail("public_basis_changed", "request evaluation time differs from trusted context")
    utc(clean["evaluation_time"])
    auth = obj(clean["authorization_context"], {"profile_id", "active", "generation"})
    integer(auth["generation"])
    text(auth["profile_id"])
    if auth["active"] is not True:
        fail("authorization_context_required", "active local authorization required")
    task = obj(clean["task"], {"scope", "public_goal"}, set("fields allow_rearrangement fixed_character_ids excluded_character_ids locked_local_instance_ids".split()))
    obj(task["scope"], set("game_version environment mode_id cycle_id stage_id stage_revision".split()))
    feedback_shape(clean.get("feedback"), task, limits)
    budget = Budget(limits)
    budget.check(clean)
    descriptor, tombstones = verify_public_basis(clean, policy, budget)
    a = obj(clean["public_bundle"], set("producer producer_commit format_profile raw_json sha256 expected_release_id".split()))
    b = obj(clean["account_snapshot"], set("producer producer_commit format_profile raw_json sha256".split()))
    distribution, encoded = budget.raw(a["raw_json"], limits["envelope_raw_bytes"])
    budget.raw(b["raw_json"], limits["snapshot_raw_bytes"])
    selected = clean["public_basis"]["selected_artifact"]
    if (hashlib.sha256(encoded).hexdigest() != selected["envelope_sha256"]
            or a["sha256"] != selected["envelope_sha256"] or len(encoded) != descriptor["size_bytes"]
            or a["expected_release_id"] != selected["release_id"]):
        fail("artifact_identity_mismatch", "selected artifact digest/size/release differs from original envelope bytes")
    manifest = distribution.get("manifest")
    if type(manifest) is not dict:
        fail("invalid_public_bundle", "distribution manifest is required")
    a_identity = {**selected["a_producer"], "envelope_profile": a["format_profile"],
                  "native_profile": manifest.get("native_profile"), "planner_profile": manifest.get("planner_profile")}
    if (a_identity not in config["allowed_a_producers"] or a["producer_commit"] != a_identity["commit"]
            or a["format_profile"] != descriptor["envelope_profile"]):
        fail("unsupported_producer_version", "A actual producer tuple is not admitted")
    b_identity = {"profile": b["format_profile"], "producer_commit": b["producer_commit"]}
    if b_identity != selected["b_snapshot"] or b_identity not in config["allowed_b_snapshots"]:
        fail("unsupported_producer_version", "B actual snapshot source tuple is not admitted")
    key = signing_key(config, manifest.get("signing_key_id"), "synthetic-release", utc(context["evaluation_time"]))
    public, a_proof = _adapt_distribution(a, {"purpose": "synthetic-test", "public_keys": {key["key_id"]: key["public_key_hex"]}}, {a_identity["commit"]: a_identity["version"]})
    snapshot, b_proof, diagnostics = _adapt_snapshot(b, auth, public["entities"], {b_identity["producer_commit"]: b_identity["profile"]})
    withdrawn, bindings, unmatched = map_revocations(a_proof, public, tombstones)
    native = {
        "schema_id": "AnalysisRequest", "schema_version": "0.1-draft", "contract_version": "0.1-draft",
        "adapter_profile": NATIVE, "local_rule_version": "0.2.0", "request_id": clean["request_id"],
        "authorization_generation": snapshot["authorization_generation"], "public_bundle": public,
        "account_snapshot": snapshot, "task": task, "feedback": clean.get("feedback"),
        "evaluation_time": clean["evaluation_time"],
        "latest_known_validity": {"withdrawn_public_refs": withdrawn},
    }
    validate_json_request(native)
    metadata = {
        "request_id": clean["request_id"], "snapshot_revision": snapshot["snapshot_revision"],
        "authorization_generation": snapshot["authorization_generation"],
        "request_producer": clean["request_producer"], "request_sha256": digest(clean),
        "feedback_sha256": digest(clean.get("feedback")),
        "public_basis_sha256": clean["public_basis_sha256"], "public_epoch": clean["public_basis"]["epoch"],
        "producer_provenance": {"public_bundle": a_proof, "account_snapshot": b_proof},
        "compatibility": {"diagnostics": diagnostics, "native_rule_profile": NATIVE,
                          "core_rule_version": "0.2.0", "production_trust_established": False,
                          "typed_identity_bindings": bindings, "unmatched_tombstones": unmatched,
                          "mapped_withdrawn_refs": withdrawn,
                          "trust_basis": "separately injected host policy; no claim of independent host authentication"},
    }
    return native, metadata


def analyze_producers_v2(request, *, execution_policy):
    """Analyze synthetic v0.2 input under a separately supplied trusted host policy.

    Expected failures return v0.2 errors, never legacy fallback or invented plans.
    An invalid/unverified request does not receive authenticated digest echoes.
    """
    metadata = {}
    response_limit = LIMITS["response_bytes"]
    base = {"schema_id": "ProducerAnalysisResult", "schema_version": "0.2",
            "adapter_profile": PROFILE, "component_version": COMPONENT_VERSION}
    try:
        policy = validate_execution_policy(execution_policy)
        response_limit = policy["config"]["limits"]["response_bytes"]
        native, metadata = _prepare(request, policy)
        analysis = analyze(native)
        result = {**base, **metadata, "status": analysis["status"], "analysis": analysis}
        if analysis["status"] == "error":
            result["error"] = analysis["error"]
        bounded_encoding(result, response_limit)
        return result
    except AdaptationError as exc:
        error = {"code": exc.code, "message": str(exc), "details": exc.details, "retryable": False}
    except (ValueError, TypeError, KeyError, AttributeError, OverflowError, RecursionError, UnicodeError):
        error = {"code": "invalid_producer_payload", "message": "invalid bounded v0.2 input", "details": [], "retryable": False}
    result = {**base, **metadata, "status": "error", "analysis": None, "error": error}
    if len(canonical(result)) + 1 > response_limit:
        # No verified result is emitted when even its correlation envelope is too large.
        result = {**base, "status": "error", "analysis": None,
                  "error": {"code": "local_payload_too_large", "message": "bounded response cannot contain this result"}}
    return result


def validate_outer_request_v2(outer, *, execution_policy):
    """Validate full encoded host wrapper and return a detached inner request.

    The host must additionally bound the actual bytes read, reject duplicate keys
    while decoding, and compare all returned basis/correlation digests on receipt.
    """
    policy = validate_execution_policy(execution_policy)
    limits = policy["config"]["limits"]
    clean = copy_json(outer, limits)
    bounded_encoding(clean, limits["request_bytes"])
    obj(clean, set("schema_id schema_version request_id authorization_generation account_snapshot producer_request".split()))
    if clean["schema_id"] != "AnalysisRequest" or clean["schema_version"] != "0.2":
        fail("unsupported_adapter_profile", "new outer transport must select schema 0.2")
    integer(clean["authorization_generation"])
    inner = obj(clean["producer_request"], INNER_KEYS, {"feedback"})
    if inner["schema_id"] != "ProducerAnalysisRequest" or inner["schema_version"] != "0.2" or inner["adapter_profile"] != PROFILE:
        fail("unsupported_adapter_profile", "outer cannot carry a legacy or unknown producer profile")
    text(clean["request_id"])
    summary = obj(clean["account_snapshot"], set("profile_id snapshot_revision authorization_generation authorization_state".split()))
    integer(summary["snapshot_revision"])
    integer(summary["authorization_generation"])
    auth = obj(inner["authorization_context"], {"profile_id", "active", "generation"})
    integer(auth["generation"])
    source = obj(inner["account_snapshot"], set("producer producer_commit format_profile raw_json sha256".split()))
    raw, _ = Budget(limits).raw(source["raw_json"], limits["snapshot_raw_bytes"])
    if (clean["request_id"] != inner["request_id"] or summary["authorization_state"] != "active"
            or auth["active"] is not True or auth["profile_id"] != summary["profile_id"]
            or raw.get("profile_id") != summary["profile_id"] or raw.get("revision") != summary["snapshot_revision"]
            or auth["generation"] != clean["authorization_generation"]
            or summary["authorization_generation"] != clean["authorization_generation"]):
        fail("request_correlation_mismatch", "outer, serialized snapshot and authorization correlation differ")
    return inner
