"""Bind typed tombstones to verified A native content before legacy projection."""

from __future__ import annotations

from ..common import fail
from .schema import HASH_PROFILE, hex_value, typed_ref


def map_revocations(a_proof, normalized, tombstones):
    bindings = []
    for row in a_proof["original_member_provenance"]:
        bindings.append({key: row[key] for key in ("kind", "id", "revision", "content_hash")})
    projected_evidence = {row["id"]: row for row in normalized["evidence"]}
    for evidence in a_proof["original_evidence_provenance"]:
        projected = projected_evidence.get(evidence["id"])
        if (not projected or projected["revision"] != 1
                or projected.get("source_content_hash") != evidence["content_hash"]):
            fail("revocation_identity_mismatch", "evidence revision/hash mapping is not proven")
        bindings.append({"kind": "evidence", "id": evidence["id"], "revision": 1,
                         "content_hash": evidence["content_hash"]})
    native = {}
    untyped = {}
    for row in bindings:
        row["hash_profile"] = HASH_PROFILE
        hex_value(row["content_hash"])
        key = row["kind"], row["id"], row["revision"]
        if key in native:
            fail("revocation_identity_ambiguous", "duplicate verified native identity")
        native[key] = row
        untyped.setdefault((row["id"], row["revision"]), []).append(row)
    if any(len(values) != 1 for values in untyped.values()):
        fail("revocation_identity_ambiguous", "cross-kind ID/revision cannot be losslessly represented by the legacy core")
    mapped, unmatched, seen = set(), [], set()
    for tombstone in tombstones:
        typed_ref(tombstone)
        identity = tuple(tombstone[k] for k in ("kind", "id", "revision", "hash_profile", "content_hash"))
        if identity in seen:
            continue
        seen.add(identity)
        key = tombstone["kind"], tombstone["id"], tombstone["revision"]
        target = native.get(key)
        if target is None:
            unmatched.append(tombstone)
            continue
        if target["content_hash"] != tombstone["content_hash"]:
            fail("revocation_identity_mismatch", "tombstone hash differs from the verified native content field")
        mapped.add(f"{target['id']}@{target['revision']}")
    return sorted(mapped), sorted(bindings, key=lambda r: (r["kind"], r["id"], r["revision"])), unmatched
